# Install dependencies
npm install

# Run Server
node app