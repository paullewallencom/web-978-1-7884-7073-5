## Client Management
A list of current clients
First Name | Last Name | Phone | Email
------------ | ------------
John | Doe | 555-555-5555 | [jdoe@gmail.com](mailto:jdoe@gmail.com)
Sam | Smith | 444-444-4444 | [ssmith@gmail.com](mailto:ssmith@gmail.com)
Kathy | Johnson | 333-333-3333 | [kj@gmail.com](mailto:kj@gmail.com)
Derek | Williams | 222-222-2222 | [dwilliams@gmail.com](mailto:dwilliams@gmail.com)

### Todays Tasks
- [ ]Call John Doe about project
- [x] Meeting with Kathy at 2:00pm
- [x] Meeting with Derek at 4:00pm
- [ ] Go home

___