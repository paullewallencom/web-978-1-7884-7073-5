function greet(a){console.log(a);return a}var greeting="Hello World";null!=greeting&&greet(greeting);for(var i=0;10>i;i++)console.log(i);
