# USAGE
run "npm install" to install dependencies

run "npm start" to start server/app